import DropDown from "../components/CoursesDropDown";

const Courses= ()=>{
    return (
        <>
        <DropDown/>
        </>
    )
}

export default Courses;