import { useState } from "react"
import styles from '../css/Courses.module.css'

const DropDown = () => {
    const [pickACourse, setPickACourse] = useState('Active');
    const handleChange = (e) => {
        const { value } = e.target;
        setPickACourse(value);
    }
    return (
        <>
            <div className={styles.dropdown}>
                <select>
                    <option value={pickACourse}>Active</option>
                    <option value={pickACourse}>Inactive</option>
                    <option value={pickACourse}>Both</option>
                </select>
            </div>
        </>
    )
}

export default DropDown;