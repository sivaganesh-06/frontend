const CoursesData= {
    Active: ['C','Java Full Stack','Python Full Stack','MERN ']
}