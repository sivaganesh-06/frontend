import LoginPage from './pages/LoginPage';
import SignUpPage from './pages/SignUpPage';
import Courses from './pages/CoursesPage';
import {
    createBrowserRouter,
    RouterProvider,
} from "react-router-dom";


const router = createBrowserRouter([
    {
        path: "/",
        element: <LoginPage />
    },
    {
        path: "/signup",
        element: <SignUpPage />
    },
    {
        path: "/courses",
        element: <Courses/>
    },
])

function App() {
    return (
        <RouterProvider router={router} />
    )
}

export default App